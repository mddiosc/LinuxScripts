*******************************************************************
# Módulo de gestión de certificados
## Autor: Miguel Ángel de Dios Calles
### Directorio KEY
*******************************************************************

En este directorio se almacenarán los ficheros de claves privadas (key) que se utilizarán para generar los CSR y configurar los sitios seguros en el servidor web Apache.


Fichero | Uso
| --- | --- |
*.key | Clave Privada del dominio 