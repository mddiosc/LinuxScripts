*******************************************************************
# Módulo de gestión de certificados
## Autor: Miguel Ángel de Dios Calles
### Directorio PLT
*******************************************************************

En este directorio se almacenarán las plantillas que serán utilizadas para la generación de CSR s, CA s y Keys


Fichero | Uso
| --- | --- |
csr.plt | Plantilla para la creación de CSR
key.plt | Plantilla para la creación de Claves Privadas (keys)
CA.plt | Plantilla para la creación de entidades de certificacion (CA)
