export DIRBASE=$PWD
echo $DIRBASE
pais='ES'
echo $pais
read -p "País [ES]: " pais
read -p "Estado: " estado
read -p "Ciudad: " ciudad
read -p "Organización: " organizacion
read -p "Nombre de dominio : " fqdn
read -p "Direccion email: " email
echo $pais
echo $estado
echo $ciudad
echo $organizacion
echo $fqdn
echo $email




