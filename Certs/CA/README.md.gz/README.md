*******************************************************************
# Módulo de gestión de certificados
## Autor: Miguel Ángel de Dios Calles
### Directorio CA
*******************************************************************

En este directorio se almacenarán los ficheros de CA generados por la herramienta.

