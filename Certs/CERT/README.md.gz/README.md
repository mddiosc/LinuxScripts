*******************************************************************
# Módulo de gestión de certificados
## Autor: Miguel Ángel de Dios Calles
### Directorio CERT
*******************************************************************

En este directorio se almacenarán los certificados autofirmados generados por la herramienta
