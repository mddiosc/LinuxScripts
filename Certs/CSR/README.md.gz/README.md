*******************************************************************
# Módulo de gestión de certificados
## Autor: Miguel Ángel de Dios Calles
### Directorio CSR
*******************************************************************

En este directorio se almacenarán los ficheros de peticion de firma de certificados (CSR) que se utilizarán para generar posteriormente los certificados seguros. Todos los ficheros tendran extension .csr.


Fichero | Uso
| --- | --- |
*.csr | Ficheros de solicitud de firma de certificado seguro.